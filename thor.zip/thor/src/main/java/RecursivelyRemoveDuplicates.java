public class RecursivelyRemoveDuplicates {
    public static void main(String[] args) {
        String s = "teeksforteek";



    }
}
